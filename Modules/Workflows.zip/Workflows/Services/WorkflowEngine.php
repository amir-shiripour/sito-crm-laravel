<?php

namespace Modules\Workflows\Services;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use Morilog\Jalali\Jalalian;
use Modules\Workflows\Entities\Workflow;
use Modules\Workflows\Entities\WorkflowStage;
use Modules\Workflows\Entities\WorkflowAction;
use Modules\Workflows\Entities\WorkflowInstance;
use Modules\Workflows\Entities\WorkflowLog;
use Modules\Workflows\Entities\WorkflowTrigger;

class WorkflowEngine
{
    public function startWorkflow(Workflow $workflow, ?string $relatedType = null, ?int $relatedId = null, array $payload = []): ?WorkflowInstance
    {
        Log::info("[Workflows] Request to start workflow: '{$workflow->key}' for {$relatedType}:{$relatedId}");

        if (!$workflow->is_active) {
            Log::warning("[Workflows] Workflow inactive: '{$workflow->key}'");
            return null;
        }

        $initialStage = $workflow->stages()->where('is_initial', true)->orderBy('sort_order')->first()
            ?: $workflow->stages()->orderBy('sort_order')->first();

        if (! $initialStage) {
            Log::warning("[Workflows] No initial stage found for workflow: '{$workflow->name}'");
            return null;
        }

        return DB::transaction(function () use ($workflow, $initialStage, $relatedType, $relatedId, $payload) {
            $instance = WorkflowInstance::create([
                'workflow_id'      => $workflow->id,
                'related_type'     => $relatedType ?? 'WORKFLOW_SCHEDULE',
                'related_id'       => $relatedId ?? 0,
                'current_stage_id' => $initialStage->id,
                'status'           => WorkflowInstance::STATUS_ACTIVE,
                'started_at'       => now(),
                'created_by'       => Auth::id(),
                'payload'          => $payload, // Store payload if column exists, or handle it in context
            ]);

            // If payload column doesn't exist in WorkflowInstance, we can't store it directly there.
            // But we can pass it to runStageActions.
            // For now, let's assume we pass it via context building.

            Log::info("[Workflows] Instance created: {$instance->id}. Running initial stage actions.");
            $this->runStageActions($instance, $initialStage, $payload);

            return $instance;
        });
    }

    public function start(string $workflowKey, string $relatedType, int $relatedId, array $payload = []): ?WorkflowInstance
    {
        // 1. Try to find workflow by key (Legacy/Direct trigger)
        $workflow = Workflow::where('key', $workflowKey)->first();
        if ($workflow) {
            return $this->startWorkflow($workflow, $relatedType, $relatedId, $payload);
        }

        // 2. Try to find workflows by EVENT trigger
        // We look for workflows that have a trigger of type EVENT with config->event_key matching the workflowKey
        $workflows = Workflow::whereHas('triggers', function ($q) use ($workflowKey) {
            $q->where('type', WorkflowTrigger::TYPE_EVENT)
              ->whereJsonContains('config->event_key', $workflowKey);
        })->get();

        if ($workflows->isEmpty()) {
            Log::warning("[Workflows] No workflow found for key/event: '{$workflowKey}'");
            return null;
        }

        $lastInstance = null;
        foreach ($workflows as $wf) {
            $lastInstance = $this->startWorkflow($wf, $relatedType, $relatedId, $payload);
        }

        return $lastInstance;
    }

    public function moveToStage(WorkflowInstance $instance, WorkflowStage $stage): void
    {
        DB::transaction(function () use ($instance, $stage) {
            $instance->current_stage_id = $stage->id;
            $instance->save();

            $this->runStageActions($instance, $stage);
        });
    }

    protected function runStageActions(WorkflowInstance $instance, WorkflowStage $stage, array $payload = []): void
    {
        $actions = $stage->actions()->orderBy('sort_order')->get();
        Log::info("[Workflows] Found " . $actions->count() . " actions for stage: {$stage->name}");

        $context = $this->buildContextData($instance, $payload);

        foreach ($actions as $action) {
            try {
                $result = $this->runAction($instance, $stage, $action, $context);

                WorkflowLog::create([
                    'instance_id' => $instance->id,
                    'stage_id'    => $stage->id,
                    'action_type' => $action->action_type,
                    'data'        => ['config' => $action->config, 'result' => $result],
                    'run_at'      => now(),
                    'user_id'     => Auth::id(),
                ]);
            } catch (\Throwable $e) {
                Log::error('[Workflows] action failed', [
                    'instance_id' => $instance->id,
                    'stage_id'    => $stage->id,
                    'action_id'   => $action->id,
                    'error'       => $e->getMessage(),
                    'trace'       => $e->getTraceAsString(),
                ]);
            }
        }
    }

    protected function runAction(WorkflowInstance $instance, WorkflowStage $stage, WorkflowAction $action, array $context): array
    {
        $config = $action->config ?? [];
        $result = ['status' => 'skipped'];
        $deps = config('workflows.dependencies', []);

        Log::info("[Workflows] Running action ID: {$action->id} Type: {$action->action_type}", ['config' => $config]);

        // Base date for offsets: appointment start time if available, otherwise workflow start time
        $baseDate = $context['appointment']->start_at_utc ?? $instance->started_at ?? now();

        // Resolve target user/assignee for Tasks/FollowUps
        $targetUserId = Auth::id();
        $assigneeTarget = $config['assignee_target'] ?? 'CURRENT_USER';

        if ($assigneeTarget === 'APPOINTMENT_PROVIDER' && isset($context['appointment'])) {
            $targetUserId = $context['appointment']->provider_user_id ?? $targetUserId;
        } elseif ($assigneeTarget === 'SPECIFIC_USER' && !empty($config['assignee_id'])) {
            $targetUserId = $config['assignee_id'];
        }

        switch ($action->action_type) {
            case WorkflowAction::TYPE_CREATE_TASK:
            case WorkflowAction::TYPE_CREATE_FOLLOWUP:
                $isTask = $action->action_type === WorkflowAction::TYPE_CREATE_TASK;
                $module = $isTask ? ($deps['tasks'] ?? null) : ($deps['followups'] ?? null);
                $class = $isTask ? 'Modules\\Tasks\\Entities\\Task' : 'Modules\\FollowUps\\Entities\\FollowUp';

                if ($this->isModuleEnabled($module) && class_exists($class)) {
                    $Model = $class;

                    $dueAt = $this->calcOffsetDate($config['offset_days'] ?? 0, $baseDate);
                    $title = $this->renderTemplate($config['title'] ?? $stage->name, $context);
                    $description = $this->renderTemplate($config['description'] ?? '', $context);

                    Log::info("[Workflows] Creating Task/FollowUp. Title: $title, Assignee: $targetUserId");

                    try {
                        $task = $Model::create([
                            'title'        => $title,
                            'description'  => $description,
                            'task_type'    => $isTask ? ($config['task_type'] ?? 'GENERAL') : 'FOLLOW_UP',
                            'assignee_id'  => $targetUserId,
                            'creator_id'   => Auth::id(),
                            'status'       => $config['status'] ?? 'TODO',
                            'priority'     => $config['priority'] ?? ($isTask ? 'MEDIUM' : 'HIGH'),
                            'due_at'       => $dueAt,
                            'related_type' => $instance->related_type,
                            'related_id'   => $instance->related_id,
                        ]);
                        Log::info("[Workflows] Task created successfully. ID: {$task->id}");
                        $result = ['status' => 'created', 'task_id' => $task->id];
                    } catch (\Exception $e) {
                        Log::error("[Workflows] Task creation threw exception: " . $e->getMessage());
                        throw $e;
                    }
                } else {
                    Log::warning("[Workflows] Module $module not enabled or class $class not found.");
                }
                break;

            case WorkflowAction::TYPE_SEND_NOTIFICATION:
                $message = $this->renderTemplate($config['message'] ?? ('اجرای مرحله '.$stage->name), $context);
                Log::info('[Workflows] notification', [
                    'instance_id' => $instance->id,
                    'message'     => $message,
                ]);
                $result = ['status' => 'logged'];
                break;

            case WorkflowAction::TYPE_SEND_SMS:
                if ($this->isModuleEnabled($deps['sms'] ?? null) && class_exists('Modules\\Sms\\Services\\SmsManager')) {
                    $to = $this->resolveTargetPhone($config, $context);
                    Log::info("[Workflows] Sending SMS to: " . ($to ?? 'NULL'));

                    if ($to) {
                        $Sms = app(\Modules\Sms\Services\SmsManager::class);
                        $params = $this->resolveSmsParams($config['params'] ?? [], $context);
                        $message = $this->renderTemplate($config['message'] ?? '', $context, $params);

                        $options = [
                            'type' => \Modules\Sms\Entities\SmsMessage::TYPE_SYSTEM,
                            'related_type' => $instance->related_type,
                            'related_id' => $instance->related_id,
                            'meta' => [
                                'workflow_id' => $instance->workflow_id,
                                'workflow_name' => $instance->workflow?->name,
                                'workflow_instance_id' => $instance->id,
                            ],
                        ];

                        if (!empty($config['offset_minutes'])) {
                            $options['scheduled_at'] = $this->calcOffsetMinutes((int) $config['offset_minutes'], $baseDate);
                        }

                        if (!empty($config['pattern_key'])) {
                            Log::info("[Workflows] Sending Pattern SMS: {$config['pattern_key']}");
                            $sms = $Sms->sendPattern($to, $config['pattern_key'], $params, $options);
                            $result = ['status' => 'pattern_sent', 'sms_id' => $sms->id, 'to' => $to];
                        } else {
                            Log::info("[Workflows] Sending Text SMS: {$message}");
                            $sms = $Sms->sendText($to, $message, $options);
                            $result = ['status' => 'text_sent', 'sms_id' => $sms->id, 'to' => $to];
                        }
                    } else {
                        Log::warning("[Workflows] SMS skipped: No phone number found.");
                        $result = ['status' => 'skipped', 'reason' => 'missing_phone'];
                    }
                } else {
                    Log::warning("[Workflows] SMS module not enabled or manager not found.");
                }
                break;
        }

        return $result;
    }

    protected function isModuleEnabled(?string $moduleName): bool
    {
        if (!$moduleName) return false;
        if (class_exists('Nwidart\\Modules\\Facades\\Module')) {
            return \Nwidart\Modules\Facades\Module::has($moduleName) && \Nwidart\Modules\Facades\Module::isEnabled($moduleName);
        }
        return true;
    }

    protected function calcOffsetDate(int $days, $base)
    {
        $base = $base ? \Illuminate\Support\Carbon::parse($base) : now();
        return $days ? $base->copy()->addDays($days) : $base;
    }

    protected function calcOffsetMinutes(int $minutes, $base)
    {
        $base = $base ? \Illuminate\Support\Carbon::parse($base) : now();
        return $minutes ? $base->copy()->addMinutes($minutes) : $base;
    }

    protected function buildContextData(WorkflowInstance $instance, array $payload = []): array
    {
        $data = ['tokens' => []];

        // Merge payload into tokens
        if (!empty($payload)) {
            $data['tokens'] = array_merge($data['tokens'], $payload);
        }

        if ($instance->related_type === 'APPOINTMENT' && class_exists('Modules\\Booking\\Entities\\Appointment')) {
            $appt = \Modules\Booking\Entities\Appointment::query()
                ->with(['client', 'service', 'provider'])
                ->find($instance->related_id);

            if ($appt) {
                $scheduleTz = config('booking.timezones.display_default', 'Asia/Tehran');
                $dateJalali = $appt->start_at_utc ? Jalalian::fromDateTime($appt->start_at_utc->copy()->timezone($scheduleTz)) : null;

                // Check if route exists before using it
                $paymentLink = Route::has('booking.payment.show')
                    ? route('booking.payment.show', ['id' => $appt->id])
                    : '#';

                $data['appointment'] = $appt;
                $data['tokens'] = array_merge($data['tokens'], [
                    'client_name' => $appt->client?->full_name,
                    'client_phone' => $appt->client?->phone,
                    'service_name' => $appt->service?->name,
                    'provider_name' => $appt->provider?->name,
                    'appointment_date_jalali' => $dateJalali?->format('Y/m/d'),
                    'appointment_time_jalali' => $dateJalali?->format('H:i'),
                    'appointment_datetime_jalali' => $dateJalali?->format('Y/m/d H:i'),
                    'payment_link' => $paymentLink,
                ]);
            }
        }

        // Handle STATEMENT context
        if ($instance->related_type === 'STATEMENT' && class_exists('Modules\\Booking\\Entities\\BookingStatement')) {
            $statement = \Modules\Booking\Entities\BookingStatement::with(['provider', 'user'])->find($instance->related_id);

            if ($statement) {
                $data['statement'] = $statement;

                // Convert dates to Jalali for tokens
                $startDateJalali = Jalalian::fromCarbon(\Carbon\Carbon::parse($statement->start_date))->format('Y/m/d');
                $endDateJalali = Jalalian::fromCarbon(\Carbon\Carbon::parse($statement->end_date))->format('Y/m/d');

                $data['tokens'] = array_merge($data['tokens'], [
                    'statement_id' => $statement->id,
                    'provider_name' => $statement->provider?->name,
                    'provider_phone' => $statement->provider?->mobile ?? $statement->provider?->phone,
                    'start_date' => $startDateJalali,
                    'end_date' => $endDateJalali,
                    'status' => $statement->status,
                    'first_appointment_time' => $statement->first_appointment_time,
                    'last_appointment_time' => $statement->last_appointment_time,
                    'notes' => $statement->notes,
                ]);
            }
        }

        return $data;
    }

    protected function resolveTargetPhone(array $config, array $context): ?string
    {
        $target = $config['target'] ?? 'APPOINTMENT_CLIENT';

        if ($target === 'APPOINTMENT_CLIENT') {
            return $context['tokens']['client_phone'] ?? null;
        }

        if ($target === 'APPOINTMENT_PROVIDER') {
            // Assuming provider has a phone number in User model or profile
            $provider = $context['appointment']->provider ?? null;
            return $provider?->phone ?? $provider?->mobile ?? null;
        }

        // New target for Statement Provider
        if ($target === 'STATEMENT_PROVIDER') {
            return $context['tokens']['provider_phone'] ?? null;
        }

        if ($target === 'SPECIFIC_USER') {
            $userId = $config['target_user_id'] ?? null;
            if ($userId) {
                $user = User::find($userId);
                return $user?->phone ?? $user?->mobile ?? null;
            }
        }

        if ($target === 'CUSTOM_PHONE') {
            return $config['phone'] ?? null;
        }

        return null;
    }

    protected function resolveSmsParams(array $paramKeys, array $context): array
    {
        $tokens = $context['tokens'] ?? [];
        $params = [];
        foreach ($paramKeys as $key) {
            // If key is a token name, use its value. If it's a raw string (not in tokens), use it as is?
            // For now, we assume keys are token names from the dropdown.
            $params[] = $tokens[$key] ?? $key;
        }
        return $params;
    }

    protected function renderTemplate(string $template, array $context, array $indexedParams = []): string
    {
        $tokens = $context['tokens'] ?? [];

        // Replace indexed placeholders {0}, {1}, ...
        if (!empty($indexedParams)) {
            foreach ($indexedParams as $idx => $value) {
                $template = str_replace('{' . $idx . '}', (string) $value, $template);
            }
        }

        // Replace named placeholders like {client_name}
        foreach ($tokens as $key => $value) {
            $template = str_replace('{' . $key . '}', (string) $value, $template);
        }

        return $template;
    }
}
