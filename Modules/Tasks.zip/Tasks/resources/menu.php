<?php

return [
    /*[
        'key'        => 'tasks',
        'label'      => 'وظایف (Tasks)',
        'icon'       => 'heroicon-o-clipboard-document-check',
        'route'      => 'user.tasks.index',
        'permission' => 'tasks.view',
        'children'   => [],
    ],*/
    [
    'title' => 'وظایف',
    'route' => 'user.tasks.index',
    // دسترسی پایه برای دیدن لیست؛ جزئیات اسکوپ با view.all / view.assigned / view.own کنترل می‌شود
    'permission' => 'tasks.view',
    'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-subtask"><path stroke="none" d="M0 0h24v24H0z" fill="none"/><path d="M6 9l6 0" /><path d="M4 5l4 0" /><path d="M6 5v11a1 1 0 0 0 1 1h5" /><path d="M12 8a1 1 0 0 1 1 -1h6a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-6a1 1 0 0 1 -1 -1l0 -2" /><path d="M12 16a1 1 0 0 1 1 -1h6a1 1 0 0 1 1 1v2a1 1 0 0 1 -1 1h-6a1 1 0 0 1 -1 -1l0 -2" /></svg>',
    'group' => 'tasks',
    'position' => 10,
    ],
];
