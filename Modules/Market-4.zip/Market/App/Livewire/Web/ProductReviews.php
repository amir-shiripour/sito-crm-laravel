<?php

namespace Modules\Market\App\Livewire\Web;

use Livewire\Component;
use Livewire\WithPagination;
use Modules\Market\Entities\MasterProduct;
use Modules\Market\Entities\ProductReview;

class ProductReviews extends Component
{
    use WithPagination;

    public MasterProduct $product;

    // Form attributes
    public $rating = 5;
    public $comment = '';

    public function mount(MasterProduct $product)
    {
        $this->product = $product;
    }

    public function submitReview()
    {
        if (!auth()->guard('client')->check()) {
            $this->dispatch('notify', type: 'error', text: 'برای ثبت دیدگاه ابتدا باید وارد حساب کاربری خود شوید.');
            return;
        }

        $this->validate([
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'required|string|min:5|max:1000',
        ], [
            'rating.required' => 'لطفاً امتیاز خود را ثبت کنید.',
            'rating.min' => 'امتیاز انتخابی نامعتبر است.',
            'rating.max' => 'امتیاز انتخابی نامعتبر است.',
            'comment.required' => 'لطفاً متن دیدگاه خود را بنویسید.',
            'comment.min' => 'متن دیدگاه باید حداقل ۵ کاراکتر باشد.',
            'comment.max' => 'متن دیدگاه نمی‌تواند بیشتر از ۱۰۰۰ کاراکتر باشد.',
        ]);

        ProductReview::create([
            'master_product_id' => $this->product->id,
            'client_id' => auth()->guard('client')->id(),
            'rating' => $this->rating,
            'comment' => $this->comment,
            'status' => 'pending',
        ]);

        $this->reset(['rating', 'comment']);

        session()->flash('message', 'دیدگاه شما با موفقیت ثبت شد و پس از بررسی و تایید مدیریت نمایش داده خواهد شد.');
    }

    public function render()
    {
        // دریافت دیدگاه‌های تایید شده برای محصول
        $reviews = $this->product->reviews()
            ->where('status', 'approved')
            ->latest()
            ->paginate(5);

        // محاسبه آمار توزیع امتیازها
        $stats = [];
        $totalReviews = $this->product->reviews()->where('status', 'approved')->count();
        $averageRating = $this->product->reviews()->where('status', 'approved')->avg('rating') ?: 5.0;

        for ($i = 5; $i >= 1; $i--) {
            $count = $this->product->reviews()->where('status', 'approved')->where('rating', $i)->count();
            $stats[$i] = [
                'count' => $count,
                'percent' => $totalReviews > 0 ? round(($count / $totalReviews) * 100) : 0
            ];
        }

        return view('market::livewire.web.product-reviews', [
            'reviews' => $reviews,
            'stats' => $stats,
            'totalReviews' => $totalReviews,
            'averageRating' => round($averageRating, 1)
        ]);
    }
}
